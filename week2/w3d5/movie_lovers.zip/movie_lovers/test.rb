a = [1,2,3]
b = 0
a.each_with_index{ |item,index| puts item }
